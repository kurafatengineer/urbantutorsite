Global CSS files live here.

Keep header.css and footer.css as shared/global styles.
Component-specific styles belong inside homepage/<component>/<component>.css.
