/*
 * HOMEPAGE CONTROLLER
 *
 * This file will load and initialize the five homepage components.
 * Component-specific logic should stay inside each component folder.
 *
 * TODO:
 * 1. Load toggle
 * 2. Load hero
 * 3. Load tutors
 * 4. Load students
 * 5. Load classes
 */

"use strict";

document.addEventListener("DOMContentLoaded", function () {
  console.log("Homepage controller loaded.");
});
