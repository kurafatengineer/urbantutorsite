Global JavaScript files live here.

Keep header.js and footer.js as shared/global scripts.
Component-specific logic belongs inside homepage/<component>/<component>.js.
