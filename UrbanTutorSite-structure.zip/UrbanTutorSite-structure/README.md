# UrbanTutorSite Homepage Structure

This folder contains the new homepage component structure.

## Components

- homepage/toggle/
- homepage/hero/
- homepage/tutors/
- homepage/students/
- homepage/classes/

Each component has:
- `<component>.html`
- `<component>.css`
- `<component>.js`

## Migration rule

Do not delete the existing `style.css` or `script.js` yet.
Move existing functionality component-by-component first, test the site, and remove obsolete code only after everything works.

Header and footer remain global/shared components.
